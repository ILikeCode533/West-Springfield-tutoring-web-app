# Tutoring Club

A Java 21 and Spring Boot application.
Project made to enhance the tutoring club's process for west springfield and provide clear user-sign-ins and a user-friendly interface. It will handle requests and direct management of tutoring.


## Run tests

./mvnw test

## Why 
It replaces the messy old format the tutoring club had before(previously restircted to email, google forms and sloppy planning as well as no hour tracking or ratings)

## Help
To get help from this project message 703-399-9313 or email alex.aidan2009@gmail.com

## How to use this
Each file and their use: 
HTTP: The protocol a browser uses to request pages and send form data to a server.
Server-side rendering The server prepares HTML using data and sends the completed page to the browser.
Thymeleaf: A template engine that inserts server-provided values into HTML templates.
Spring Boot A framework that simplifies creating and running Java web applications.
PostgreSQL Relational database software that stores structured records and relationships.
SQL: A language used to query and change data in relational databases.
JPA: A Java standard for mapping Java objects to relational database records.
Spring Data JPA A library that simplifies common database access through repository interfaces.
Controller: The web-layer component that receives a request and selects the response.
Service layer Code:  implements the application's business rules and workflows.
Repositories: Reads/writes persistent data.
Authentication: Verififies who a user is.
Authorization: Deciding what an authenticated user is allowed to do.
Git: Version-control tool that records changes to project files, will be linked
GitHub: The platform for hosting the project GIT repositories and collaborating on code.
Modular monolith: One deployable application organized into distinct code modules.

## Current version
MVP / prototype 1  A limited early version used to test the core workflow and assumptions.